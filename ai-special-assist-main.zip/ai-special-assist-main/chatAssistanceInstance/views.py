from aquilify.shortcuts import render, render_from_string
from aquilify.responses import JsonResponse
from aquilify.wrappers import Request
import requests

OPENROUTER_API_KEY = "sk-or-v1-"

async def chatapi(request: Request):
    data = await request.json()
    user_message = data.get("message", "")

    response = requests.post(
        url="https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://yourdomain.com",  
            "X-Title": "MyCoolApp", 
        },
        json={
            "model": "openchat/openchat-7b:free",  # Free model
            "messages": [
                {
                    "role": "user",
                    "content": user_message
                }
            ]
        }
    )

    if response.status_code == 200:
        ai_reply = response.json()["choices"][0]["message"]["content"]
        return JsonResponse({"reply": ai_reply})
    else:
        return JsonResponse({
            "error": f"Failed with status {response.status_code}",
            "details": response.text
        }, status=response.status_code)
