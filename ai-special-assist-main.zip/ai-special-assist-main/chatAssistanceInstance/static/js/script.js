const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const body = document.getElementById('body');
const chatbox = document.getElementById('chatbox');
const voiceModal = document.getElementById('voiceModal');

themeToggle.addEventListener('click', () => {
    body.classList.toggle('bg-gray-900');
    body.classList.toggle('text-white');
    body.classList.toggle('bg-gray-100');
    body.classList.toggle('text-black');
    chatbox.classList.toggle('bg-gray-800');
    chatbox.classList.toggle('bg-white');
    chatbox.classList.toggle('text-black');

    if (body.classList.contains('bg-gray-100')) {
        themeIcon.classList.remove('ph-sun');
        themeIcon.classList.add('ph-moon');
    } else {
        themeIcon.classList.remove('ph-moon');
        themeIcon.classList.add('ph-sun');
    }
});

function toggleEmojiPicker() {
    document.getElementById('emojiPicker').classList.toggle('hidden');
}

function addEmoji(emoji) {
    document.getElementById('userInput').value += emoji;
}

function startListening() {

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {

        alert("Speech Recognition not supported. Use Google Chrome.");

        return;

    }


    const recognition = new SpeechRecognition();

    recognition.lang = "en-IN"; // Set the language

    recognition.interimResults = true; // Enable interim results

    recognition.continuous = true; // Keep recognition active


    // Show the voice modal

    voiceModal.style.display = "block";


    recognition.start();


    recognition.onstart = function() {

        console.log("Voice recognition started. Speak into the microphone.");

    };


    recognition.onresult = function(event) {

        const transcript = event.results[event.resultIndex][0].transcript; // Get the recognized text

        document.getElementById("userInput").value = transcript; // Populate the input field

    };


    recognition.onerror = function(event) {

        console.error("Error occurred in recognition: " + event.error);

        voiceModal.style.display = "none"; // Close the modal immediately on error

    };


    recognition.onend = function() {

        voiceModal.style.display = "none"; // Close the modal immediately when recognition ends

        recognition.start(); // Restart recognition for continuous listening

    };

}

function handleKeyPress(event) {
    if (event.key === "Enter") sendMessage();
}

async function sendMessage() {
    const inputField = document.getElementById("userInput");
    const message = inputField.value.trim();
    if (!message) return;

    document.getElementById("sendSound").play();
    appendMessage("user", message, "user-bubble");
    showTypingIndicator();

    try {
        const response = await fetch("http://127.0.0.1:39715/chatapi", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message })
        });

        const data = await response.json();
        const botReply = data.reply || "I'm not sure how to respond.";

        removeTypingIndicator();
        document.getElementById("receiveSound").play();
        appendMessage("bot", botReply, "bot-bubble");
        speakResponse(botReply);
        showQuickReplies();
    } catch (error) {
        console.error("Error fetching response:", error);
        removeTypingIndicator();
        appendMessage("bot", "Oops! Something went wrong. Try again.", "bg-red-600");
    }

    inputField.value = "";
}

function appendMessage(sender, text, bubbleClass) {
    const chatbox = document.getElementById("chatbox");
    const messageContainer = document.createElement("div");
    messageContainer.className = `message-container ${sender === "user" ? "user" : ""}`; // Add user class for alignment
    const messageDiv = document.createElement("div");
    messageDiv.className = `chat-bubble ${bubbleClass} animate-fade`;
    messageDiv.innerHTML = `
        <p class="mt-1">${formatMessage(text)}</p>
        <span class="text-xs text-gray-300 mt-2 block">${new Date().toLocaleTimeString()}</span>
    `;
    messageContainer.appendChild(messageDiv);
    chatbox.appendChild(messageContainer);
    chatbox.scrollTop = chatbox.scrollHeight;
}

function showTypingIndicator() {
    const chatbox = document.getElementById("chatbox");
    const typingIndicator = document.createElement("div");
    typingIndicator.id = "typingIndicator";
    typingIndicator.className = "text-gray-400 text-sm animate-fade";
    typingIndicator.innerHTML = '🤖 Bot is typing <span class="typing-indicator"></span><span class="typing-indicator"></span><span class="typing-indicator"></span>';
    chatbox.appendChild(typingIndicator);
    chatbox.scrollTop = chatbox.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById("typingIndicator");
    if (typingIndicator) typingIndicator.remove();
}

function formatMessage(text) {
    return text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
               .replace(/\*(.*?)\*/g, "<em>$1</em>")
               .replace(/`(.*?)`/g, "<code class='bg-gray-800 px-1 py-0.5 rounded'>$1</code>");
}

function showQuickReplies() {
    const chatbox = document.getElementById("chatbox");
    const quickReplies = ["Tell me a joke", "What's the weather?", "How are you?"];
    const quickReplyDiv = document.createElement("div");
    quickReplyDiv.className = "flex space-x-2 mt-2";

    quickReplies.forEach(reply => {
        const button = document.createElement("button");
        button.className = "px-3 py-1 bg-gray-700 rounded-full hover:bg-gray-600 transition duration-300";
        button.innerText = reply;
        button.onclick = () => {
            document.getElementById("userInput").value = reply;
            sendMessage();
        };
        quickReplyDiv.appendChild(button);
    });

    chatbox.appendChild(quickReplyDiv);
    chatbox.scrollTop = chatbox.scrollHeight;
}

function speakResponse(reply) {
    const speech = new SpeechSynthesisUtterance(reply);
    speech.lang = "en-IN";
    speechSynthesis.speak(speech);
}