 
from aquilify.db.axsql import entity, fields

# Create your modal here...

# Register Modals

# Update the `settings` `DATABASE` Dict[Dict[str, str]] -> {
#     MODALS: List[str, str] = [
#         "modals.your_modal_cls" # pass the path_to modal dotted string inside the list.
#     ]
# }
