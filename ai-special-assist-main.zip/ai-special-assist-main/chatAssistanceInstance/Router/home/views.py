from aquilify.wrappers import Request

from aquilify.responses import JsonResponse
from aquilify.shortcuts import render

class AISpecialAssistHomePage:
    
    def __init__(self):
        pass
    
    async def homepage(self, request: Request):
        if request.method == "POST":
            return JsonResponse(
                content = {"response": "%s is not Supported" %(request.method), "response_code": 405},
                status = 405
            )
            
        return await render(
            request = request, template_name = "index.html", context = {
                "title": "AI Special Assist",
                "welcome_msg": "Welcome! How can I assist you?"
            }
        )
        
specialAssistHomepage: AISpecialAssistHomePage = AISpecialAssistHomePage()