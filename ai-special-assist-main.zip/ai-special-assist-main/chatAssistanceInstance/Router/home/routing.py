from aquilify.core.schematic.routing import rule
from .views import (
    specialAssistHomepage
)

ROUTER = [
    rule("/home", specialAssistHomepage.homepage, methods = ["GET"])
]
